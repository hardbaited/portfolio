import{a as t}from"../chunks/entry.Dq1h-SPO.js";export{t as start};
