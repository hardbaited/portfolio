import{a as t}from"../chunks/entry.BvEXZ26A.js";export{t as start};
